import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Test {
public static void main(String[] args) {
	EntityManagerFactory emf = Persistence.createEntityManagerFactory("JPA-PU");

	 EntityManager entityManager = emf.createEntityManager();
	 entityManager.getTransaction().begin();
	 //create Department Entity
	 Department depart=new Department();
	// depart.setDeptno(1);
	 depart.setDloc("Cbe");
depart.setDname("computing");

//store Department
//entityManager.persist(depart);

Employee e1=new Employee( "Nandy", 50000, "Cbe",depart);
Employee e2=new Employee( "Pooja", 60000, "Chennai",depart);
Employee e3=new Employee( "Menaka", 70000, "Gpm",depart);
Employee e4=new Employee( "sindhu", 80000, "Madurai",depart);


entityManager.persist(e1);
entityManager.persist(e2);
entityManager.persist(e3);
entityManager.persist(e4);

entityManager.getTransaction().commit();

}
}
