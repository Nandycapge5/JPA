package com.empcrud.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import com.empcrud.dao.JPAUtil;
//import com.empcrud.dao.JPAUtil;
import com.empcrud.entities.EmployeeCrud;

public class EmployeeDaoImpl implements EmployeeDao{
	private EntityManager entityManager;
	EntityManagerFactory emf=Persistence.createEntityManagerFactory("JPA-PU");
    EntityManager em=emf.createEntityManager();


	public EmployeeDaoImpl() {
						entityManager = JPAUtil.getEntityManager();
	}

		@Override
	public int create(EmployeeCrud employee) {
	entityManager.persist(employee);
		return employee.getEmpId();
		// TODO Auto-generated method stub
		
	}

	@Override
	public EmployeeCrud find(int empId) {
		// TODO Auto-generated method stub
		EmployeeCrud e=entityManager.find(EmployeeCrud.class, empId);
		
		return e;
	}

	@Override
	public void update(EmployeeCrud employee) {
		// TODO Auto-generated method stub
		entityManager.merge(employee);
		
	}

	@Override
	public void delete(EmployeeCrud employee) {
		// TODO Auto-generated method stub
		entityManager.remove(employee);

	}
	
	@Override
	public void beginTransaction() {
		entityManager.getTransaction().begin();
	}

	@Override
	public void commitTransaction() {
		entityManager.getTransaction().commit();
	}



	@Override
	public EmployeeCrud getStudentById(int empId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List ListTransaction() {
		// TODO Auto-generated method stub
		entityManager.getTransaction().commit();
		TypedQuery<EmployeeCrud> q2=em.createQuery("select c from Employee c",EmployeeCrud.class);
        List<EmployeeCrud> l1=q2.getResultList();

		return l1;

		
	}
	
}
