package com.empcrud.main;

import java.util.List;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.empcrud.entities.EmployeeCrud;
import com.empcrud.service.EmployeeService;
import com.empcrud.service.EmployeeServiceImpl;

public class EmpMain {
	 static EmployeeService service=new EmployeeServiceImpl();
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EmployeeCrud e=new EmployeeCrud();
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("JPA-PU");
        EntityManager em=emf.createEntityManager();

		Scanner scan=new Scanner(System.in);
		
		while(true)
		{
System.out.println("1.Create Employee");
System.out.println("2.Find Employee");
System.out.println("3.Update Employee");
System.out.println("4.Delete Employee");
System.out.println("5.List All");
System.out.println("Enter the option");
int option=scan.nextInt();
switch(option)
{
case 1:
	//EmployeeCrud e=new EmployeeCrud();
	
		System.out.println("Enter the Employee Name");
	String empName=scan.next();
	System.out.println("Enter the Employee Salary");
	int empSal=scan.nextInt();
	System.out.println("Enter the Employee Address");
	String empAdress=scan.next();
   // e.setEmpId(empId);
	e.setEmpName(empName);
	e.setEmpAddress(empAdress);
	e.setEmpSal(empSal);
	int empId=service.create(e);
	
System.out.println(empId+" is Sucessfully Created");
	
	
break;
case 2:
	try{
	System.out.println("Enter the Employee id");
    int eid2=scan.nextInt();
    EmployeeCrud e1=service.find(eid2);
    System.out.println("ID= "+e.getEmpId());
    System.out.println("Name= "+e.getEmpName());
    System.out.println("Salary= "+e.getEmpSal());
    System.out.println("Address= "+e.getEmpAddress());}
	catch(Exception h)
	{
		System.out.println("please Enter valid Employee id");
	}
	break;
case 3:
	try{
	System.out.println("update Name");
	String empName1=scan.next();
	e.setEmpName(empName1);
	service.update(e);
	}
	catch(Exception h)
	{
		System.out.println("please Enter valid Employee id");
	}
	break;
case 4:
	try{
	System.out.println("Enter the Employee id");
	int empId3=scan.nextInt();
	EmployeeCrud e3=service.find(empId3);
	service.delete(e3);
	System.out.println("Sucessfully deleted");}
	catch(Exception h)
	{
		System.out.println("please Enter valid Employee id");

	}
	break;
case 5:
	
   

	List<EmployeeCrud> l1=service.ListTransaction();
	for(EmployeeCrud e4:l1)
    {
        System.out.println(e4.getEmpId());
       System.out.println(e4.getEmpName());
        System.out.println(e4.getEmpSal());
        System.out.println(e4.getEmpAddress());
    }
	break;
	
case 6:
	System.exit(0);
	default:
		break;
}


	}


}
}
