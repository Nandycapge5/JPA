package com.empcrud.service;

import java.util.List;

import com.empcrud.entities.EmployeeCrud;

public interface EmployeeService {
public int create(EmployeeCrud employee);
public EmployeeCrud find(int empId);
public void update(EmployeeCrud employee);
public void delete(EmployeeCrud employee);
public List ListTransaction();


}
