package com.empcrud.service;

import java.util.List;

//import com.empcrud.entities.service;
import com.empcrud.dao.EmployeeDao;
import com.empcrud.dao.EmployeeDaoImpl;
import com.empcrud.entities.EmployeeCrud;

public class EmployeeServiceImpl implements EmployeeService {
 EmployeeDao dao;
 public EmployeeServiceImpl() {
     dao = new EmployeeDaoImpl();
 
 }
	@Override
	public int create(EmployeeCrud employee) {
		// TODO Auto-generated method stub
		dao.beginTransaction();
		int empId=dao.create(employee);
		dao.commitTransaction();
		return empId;
		
	}

	@Override
	public EmployeeCrud find(int empId) {
		// TODO Auto-generated method stub
		EmployeeCrud Employee  = dao.find(empId);
		return Employee;
	}

	@Override
	public void update(EmployeeCrud employee) {
		// TODO Auto-generated method stub
		dao.beginTransaction();
		dao.update(employee);
		dao.commitTransaction();
		
	}

	@Override
	public void delete(EmployeeCrud employee) {
		// TODO Auto-generated method stub
		dao.beginTransaction();
		dao.delete(employee);
		dao.commitTransaction();
		
	}
	@Override
	public List ListTransaction() {
		// TODO Auto-generated method stub
		
	List l2=dao.ListTransaction();
		
		return l2;
		
	}

}
