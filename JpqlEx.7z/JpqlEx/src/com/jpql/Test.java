package com.jpql;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("JPA");
        EntityManager em=emf.createEntityManager();
        /*em.getTransaction().begin();
        Employee e= new Employee(1,"Nandy",1000);
        Employee e1= new Employee(2,"Menaka",2000);
        Employee e2= new Employee(3,"Pooja",3000);
        Employee e3= new Employee(4,"Sindhu",4000);
        em.persist(e);
        em.persist(e1);
        em.persist(e2);
        em.persist(e3);
        em.getTransaction().commit();
//create
             /* TypedQuery<Employee> q2=em.createQuery("select c from Employee c",Employee.class);
        List<Employee> l1=q2.getResultList();
        for(Employee e4:l1)
        {
            System.out.println(e4.getEid());
          //  System.out.println(e4.getEname());
          //  System.out.println(e4.getEsal());
        }*/
        
        /*//UPDATE
        em.getTransaction().begin();
Query q=em.createQuery("update Employee set esal=30000 where eid=2");
 
q.executeUpdate();
em.getTransaction().commit();*/
        
        /*//DELETE
        em.getTransaction().begin();
        Query q=em.createQuery("delete from Employee where eid=4");
        
        q.executeUpdate();
        em.getTransaction().commit();*/
        
        Query q4=em.createQuery("select MAX(emp.esal) from Employee emp");
        int maxsal=(int)q4.getSingleResult();
        System.out.println(maxsal);
       // em.getTransaction().commit();
       //em.close();
      // emf.close();
	}

}
