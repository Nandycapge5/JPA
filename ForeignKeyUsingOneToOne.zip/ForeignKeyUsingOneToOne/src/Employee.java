import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

@Entity
@Table(name="empone")
public class Employee {
	
	
		@Id
		@GeneratedValue
		@Column(name = "empId", length =5)
		private int empId;
		@Column(name = "empName", length =10)
		private String empName;
		@Column(name = "empSal", length =5)
		private int empSal;
		@Column(name = "empAddress", length =10)
		private String empAddress;

			public Employee( String empName, int esal, String empAddress, Department depart) {
			super();
			
			this.empName = empName;
			this.empSal = esal;
			this.empAddress = empAddress;
			//this.dept = dept;

		}
			//@ManyToOne
			//@OnDelete(action=OnDeleteAction.CASCADE)
			@OneToOne(cascade=CascadeType.ALL)
			@JoinColumn(name="AddId")
			private Department dept;
		
		public int getEmpId() {
			return empId;
		}

		public void setEmpId(int empId) {
			this.empId = empId;
		}

		public String getEmpName() {
			return empName;
		}

		public void setEmpName(String empName) {
			this.empName = empName;
		}

		public int getEmpSal() {
			return empSal;
		}

		public void setEmpSal(int empSal) {
			this.empSal = empSal;
		}

		public String getEmpAddress() {
			return empAddress;
		}

		public void setEmpAddress(String empAddress) {
			this.empAddress = empAddress;
		}
		/*public Employee(int empId, String empName, int empSal, String empAddress, Department dept) {
			super();
			this.empId = empId;
			this.empName = empName;
			this.empSal = empSal;
			this.empAddress = empAddress;
			this.dept = dept;
		}
*/
	}


