package com.annotation;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Session s=new Configuration().configure().buildSessionFactory().openSession();
		//Employee emp=s.get(Employee.class,1);
		
		
		//System.out.println(emp.getEname());
		Transaction trans=s.beginTransaction();
		Employee emp=s.get(Employee.class,1);
		//emp.setEid(2);
//		emp.setEname("sathya");
//		emp.setEsal(80000);
		emp.setEname("sathya");
		s.save(emp);//orm
		trans.commit();


	}

}
