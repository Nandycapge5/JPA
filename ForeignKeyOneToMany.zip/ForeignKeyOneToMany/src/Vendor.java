import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="vendor")
public class Vendor {

	@Id
	@Column(name="vid",length=4)
	private int VendorId;
	@Column(name="vname",length=10)
private String vendorName;
	@OneToMany(targetEntity=Customers.class,cascade=CascadeType.ALL)
	@JoinColumn(name="venid",referencedColumnName="vid")
	
	private Set Childern;
	public int getVendorId() {
		return VendorId;
	}
	public void setVendorId(int vendorId) {
		VendorId = vendorId;
	}
	public String getVendorName() {
		return vendorName;
	}
	public void setVendorName(String vendorName) {
		this.vendorName = vendorName;
	}
	public Set getChildern() {
		return Childern;
	}
	public void setChildern(Set childern) {
		Childern = childern;
	}
	
	

}
