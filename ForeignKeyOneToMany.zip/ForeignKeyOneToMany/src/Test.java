import java.util.HashSet;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Test {
public static void main(String[] args) {
	
	

	EntityManagerFactory emf = Persistence.createEntityManagerFactory("onetomany");

	 EntityManager em = emf.createEntityManager();
	 em.getTransaction().begin();
	 
	 Vendor v=new Vendor();
	 v.setVendorId(1);
	 v.setVendorName("magha");
	 
	 
	 Customers c=new Customers();
	 c.setCustomerId(2);
	 c.setCustomerName("cit");
	 Customers c1=new Customers();
	 c1.setCustomerId(3);
	 c1.setCustomerName("psg");
	 
	 
	 Set s=new HashSet();
	 s.add(c);
	 s.add(c1);
	 v.setChildern(s);
	 em.persist(v);

}
}
