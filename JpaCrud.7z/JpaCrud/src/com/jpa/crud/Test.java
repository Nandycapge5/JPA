package com.jpa.crud;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import oracle.net.aso.e;

public class Test {
	public static void main(String[] args) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("JPA");
		EntityManager em = emf.createEntityManager();
		// find method
		/*
		 * Employee e=em.find(Employee.class,3);
		 * System.out.println(e.getEname());
		 */

		// update
		
		/*em.getTransaction().begin();
		Employee e2 = em.find(Employee.class, 3);
		e2.setEname("Samvitha");
		em.persist(e2);
		em.getTransaction().commit();
		System.out.println(e2);*/

		
		// remove method
		
		 em.getTransaction().begin();
		 Employee r=em.find(Employee.class,6);
		 em.remove(r);
	 	 em.getTransaction().commit();

		
		  /*// 1)insert method=persist
		   em.getTransaction().begin(); 
		  Employee e1 =new Employee(6, "Megan", 80000);
		    em.persist(e1);
		  em.getTransaction().commit();*/
		 

		/*
		 * em.persist(e); em.getTransaction().commit();
		 */
		// System.out.println(e.getEname());

	}
}
